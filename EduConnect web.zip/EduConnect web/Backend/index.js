const express= require('express');
const User = require('./User');
const bodyParser = require('body-parser');
const db = require('./config');

 const app = express();
app.use(bodyParser.json()); //req.body

const PORT = 3000;

//Import the router files
const userRoutes = require('./userRoutes');


//Use the routers
app.use('/',userRoutes);


app.listen(PORT ,()=>{
console.log('listening on port 3000');
})
