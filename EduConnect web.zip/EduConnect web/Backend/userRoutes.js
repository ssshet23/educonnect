const express = require('express')
const router = express.Router();
const User = require('./User');

//POST route to add a person
router.post('/signup', async (req,res)=>{
    try{
        const data= req.body //the data sent is parsed by the bodyParser n stored in req.body
      
        // Create a new User doc using the mongoose model
         const newUser = new User(data);
      
        //save the new user to the database
        const response = await newUser.save();
        console.log('data saved');

       
        res.status(200).json({response: response});
      }
      catch(e){
        console.log('An Error Occured : ', e);
        res.status(500).json({error:'Bad request'});
      }
      })

      module.exports = router;