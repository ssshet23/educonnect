const mongoose =  require('mongoose');

// const bcrypt= require('bcrypt');

//Define the MongoDB connection URL
const mongoURL ='mongodb://localhost:27017/Login';

//set up MongoDB Connection
mongoose.connect(mongoURL,{
    useNewUrlParser:true,
    useUnifiedTopology: true
})

//get the default connection
//Mongoose maintain a default connection object representing the MongoDB connection
const db = mongoose.connection;

//Define the eventListeners for database connection
//These eventListeners allow u to react to different states of dadtbase connection
db.on('connected',()=>{
    console.log('Connected to MongoDB server');

});
db.on('error',(err)=>{
    console.log(' MongoDB connection error:',err);

});
db.on('disconnected',()=>{
    console.log(' MongoDB disconnected');

});



//Export the database connection
//U export the database obj db,which represents the MOngoDB connection so that u can import and use it in the other parts of ur NOde.js application
module.exports= db;//Export it to serverWithExpress.js


